﻿namespace VRTK
{
    using UnityEngine;

    public class WindowsMR_ControllerManager : MonoBehaviour
    {
    }
}